# HealthWise Smart Premium Engine

| File | Purpose |
|---|---|
| `HealthWise_Lab.ipynb` | Completed lab notebook (all cells run, reflections + board memo included) |
| `train_model.py` | Re-trains everything -> `healthwise_model.joblib`, `metrics.json`, `healthwise_clean.csv` |
| `app.py` | Streamlit dashboard (calculator, batch scoring, model performance, feature insights) |
| `healthwise.csv` | Original data |
| `sample_customers.csv` | Example file for batch scoring in the dashboard |
| `requirements.txt` | Python dependencies |

## Run
```
pip install -r requirements.txt
python train_model.py          # (artefacts are already included, only needed to retrain)
streamlit run app.py
```
Keep `app.py`, `healthwise_model.joblib`, `metrics.json` and `healthwise_clean.csv` in the same folder.
Rename the notebook to `HealthWise_<YourName>_<RollNo>.ipynb` before submitting.
