"""HealthWise - trains the two-stage Smart Premium Engine and saves artefacts.
Run:  python train_model.py
Outputs: healthwise_model.joblib, metrics.json, healthwise_clean.csv
"""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LinearRegression, Ridge, Lasso, LogisticRegression
from sklearn.metrics import (mean_absolute_error, mean_squared_error, r2_score,
                             accuracy_score, confusion_matrix)

RANDOM_STATE = 42
TIERS = ['Low', 'Medium', 'High']
NUM = ['age', 'bmi', 'children', 'exercise_freq']
CAT = ['sex', 'smoker', 'region']
FEATURES = NUM + CAT
DROPPED = {
    'customer_id': 'identifier',
    'favorite_color': 'irrelevant', 'zodiac_sign': 'irrelevant (12-category noise)',
    'lucky_number': 'irrelevant', 'preferred_contact': 'irrelevant',
    'marketing_opt_in': 'irrelevant',
    'date_of_birth': 'redundant with age', 'weight_kg': 'redundant with bmi (r=0.99)',
}


def make_pre():
    return ColumnTransformer([('num', 'passthrough', NUM),
                              ('cat', OneHotEncoder(handle_unknown='ignore', drop='first'), CAT)])


def load_clean(path='healthwise.csv'):
    df = pd.read_csv(path)
    n0 = len(df)
    df = df.drop_duplicates().reset_index(drop=True)
    info = {'rows_raw': n0, 'duplicates_removed': n0 - len(df),
            'missing_bmi': int(df['bmi'].isna().sum()),
            'missing_exercise': int(df['exercise_freq'].isna().sum())}
    med = {c: float(df[c].median()) for c in NUM}
    for c in ['bmi', 'exercise_freq']:
        df[c] = df[c].fillna(med[c])
    return df, med, info


def rmse(a, b):
    return float(np.sqrt(mean_squared_error(a, b)))


def main():
    df, med, info = load_clean()
    df[FEATURES + ['annual_charge', 'risk_tier']].to_csv('healthwise_clean.csv', index=False)
    M = {'cleaning': info, 'dropped': DROPPED}

    # ---------- Stage 1: classifier ----------
    Xtr, Xte, ytr, yte = train_test_split(df[FEATURES], df['risk_tier'], test_size=0.2,
                                          random_state=RANDOM_STATE, stratify=df['risk_tier'])
    cands = {
        'Logistic Regression': Pipeline([('pre', make_pre()), ('sc', StandardScaler(with_mean=False)),
                                         ('model', LogisticRegression(max_iter=2000))]),
        'Decision Tree (depth 5)': Pipeline([('pre', make_pre()),
                                             ('model', DecisionTreeClassifier(max_depth=5, random_state=RANDOM_STATE))]),
    }
    cls_res = {}
    for name, p in cands.items():
        p.fit(Xtr, ytr)
        cls_res[name] = {'train_acc': accuracy_score(ytr, p.predict(Xtr)),
                         'test_acc': accuracy_score(yte, p.predict(Xte))}
    best = max(cls_res, key=lambda k: cls_res[k]['test_acc'])
    clf = cands[best]
    pred = clf.predict(Xte)
    M['classifier'] = {'candidates': cls_res, 'chosen': best,
                       'confusion_matrix': confusion_matrix(yte, pred, labels=TIERS).tolist(),
                       'labels': TIERS}

    # ---------- Global baseline ----------
    Xtr, Xte, ytr, yte = train_test_split(df[FEATURES], df['annual_charge'], test_size=0.2,
                                          random_state=RANDOM_STATE)
    g = Pipeline([('pre', make_pre()), ('model', LinearRegression())]).fit(Xtr, ytr)
    gp = g.predict(Xte)
    M['global'] = {'mae': mean_absolute_error(yte, gp), 'rmse': rmse(yte, gp), 'r2': r2_score(yte, gp)}

    # ---------- Stage 2: per-tier regression (+ Ridge/Lasso tuning) ----------
    tier_res, t_true, t_pred = {}, [], []
    for t in TIERS:
        d = df[df['risk_tier'] == t]
        a, b, c, e = train_test_split(d[FEATURES], d['annual_charge'], test_size=0.2, random_state=RANDOM_STATE)
        lin = Pipeline([('pre', make_pre()), ('model', LinearRegression())]).fit(a, c)
        p = lin.predict(b)
        t_true += list(e); t_pred += list(p)
        sweep = {}
        for al in [0.01, 0.1, 1, 10, 50, 100, 200]:
            r = Pipeline([('pre', make_pre()), ('sc', StandardScaler()), ('model', Ridge(alpha=al))]).fit(a, c)
            l = Pipeline([('pre', make_pre()), ('sc', StandardScaler()), ('model', Lasso(alpha=al, max_iter=20000))]).fit(a, c)
            sweep[al] = {'ridge': r2_score(e, r.predict(b)), 'lasso': r2_score(e, l.predict(b))}
        tier_res[t] = {'n': len(d), 'r2': r2_score(e, p), 'mae': mean_absolute_error(e, p), 'alpha_sweep': sweep}
    M['tiers'] = tier_res
    M['two_stage_oracle'] = {'mae': mean_absolute_error(t_true, t_pred), 'rmse': rmse(t_true, t_pred),
                             'r2': r2_score(t_true, t_pred)}

    # Honest end-to-end: classifier predicts tier -> that tier's regressor predicts charge (same hold-out)
    tr_idx, te_idx = train_test_split(df.index, test_size=0.2, random_state=RANDOM_STATE, stratify=df['risk_tier'])
    tr, te = df.loc[tr_idx], df.loc[te_idx]
    clf_e = Pipeline(clf.steps).fit(tr[FEATURES], tr['risk_tier'])
    regs_e = {t: Pipeline([('pre', make_pre()), ('model', LinearRegression())])
              .fit(tr[tr.risk_tier == t][FEATURES], tr[tr.risk_tier == t]['annual_charge']) for t in TIERS}
    pt = clf_e.predict(te[FEATURES])
    pe = np.array([regs_e[t].predict(te.iloc[[i]][FEATURES])[0] for i, t in enumerate(pt)])
    gE = Pipeline([('pre', make_pre()), ('model', LinearRegression())]).fit(tr[FEATURES], tr['annual_charge'])
    pg = gE.predict(te[FEATURES])
    M['end_to_end'] = {'two_stage': {'mae': mean_absolute_error(te['annual_charge'], pe),
                                     'r2': r2_score(te['annual_charge'], pe)},
                       'global': {'mae': mean_absolute_error(te['annual_charge'], pg),
                                  'r2': r2_score(te['annual_charge'], pg)}}

    # ---------- Final models on ALL data -> deploy ----------
    clf.fit(df[FEATURES], df['risk_tier'])
    regs = {t: Pipeline([('pre', make_pre()), ('model', LinearRegression())])
            .fit(df[df.risk_tier == t][FEATURES], df[df.risk_tier == t]['annual_charge']) for t in TIERS}
    names = NUM + list(clf.named_steps['pre'].named_transformers_['cat'].get_feature_names_out(CAT))
    M['coefficients'] = {t: dict(zip(names, map(float, regs[t].named_steps['model'].coef_))) for t in TIERS}

    joblib.dump({'clf': clf, 'regs': regs, 'features': FEATURES, 'num': NUM, 'cat': CAT, 'med': med},
                'healthwise_model.joblib')
    json.dump(M, open('metrics.json', 'w'), indent=2, default=float)
    print(json.dumps({k: M[k] for k in ['cleaning', 'global', 'two_stage_oracle', 'end_to_end']}, indent=1, default=float))
    print(M['classifier']['chosen'], M['classifier']['candidates'])
    for t in TIERS:
        print(t, {k: round(v, 3) if isinstance(v, float) else v for k, v in tier_res[t].items() if k != 'alpha_sweep'})


if __name__ == '__main__':
    main()
