"""HealthWise - Smart Premium Engine dashboard.   Run:  streamlit run app.py"""
import json
import joblib
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

st.set_page_config(page_title="HealthWise Smart Premium Engine", page_icon="🏥", layout="wide")

TIERS = ['Low', 'Medium', 'High']
COLORS = {'Low': '#2e9e5b', 'Medium': '#e8a317', 'High': '#d64545'}


@st.cache_resource
def load_model():
    return joblib.load('healthwise_model.joblib')


@st.cache_data
def load_metrics():
    return json.load(open('metrics.json'))


@st.cache_data
def load_data():
    return pd.read_csv('healthwise_clean.csv')


M, MET, DATA = load_model(), load_metrics(), load_data()
clf, regs, FEATURES, NUM, med = M['clf'], M['regs'], M['features'], M['num'], M['med']


def predict(c: dict):
    """Stage 1: classify tier -> Stage 2: that tier's regressor gives the premium."""
    row = pd.DataFrame([c])
    for k in NUM:
        if k not in row or pd.isna(row.at[0, k]):
            row[k] = med[k]
    tier = clf.predict(row[FEATURES])[0]
    return tier, float(regs[tier].predict(row[FEATURES])[0])


st.title("🏥 HealthWise — Smart Premium Engine")
st.caption("Two-stage ML: ① classify the customer's risk tier → ② predict the charge with that tier's own regression model.")

tab1, tab2, tab3, tab4 = st.tabs(["🧮 Premium Calculator", "📂 Batch Scoring",
                                  "📊 Model Performance", "🔍 Data & Feature Insights"])

# ------------------------------------------------------------------ TAB 1
with tab1:
    left, right = st.columns([1, 1.2])
    with left:
        st.subheader("Customer profile")
        age = st.slider("Age", 18, 64, 40)
        bmi = st.slider("BMI", 16.0, 50.0, 27.0, 0.1)
        children = st.slider("Children", 0, 4, 1)
        exercise = st.slider("Exercise (workouts / week)", 0, 7, 3)
        c1, c2, c3 = st.columns(3)
        sex = c1.selectbox("Sex", ["male", "female"])
        smoker = c2.selectbox("Smoker", ["no", "yes"])
        region = c3.selectbox("Region", ["north", "south", "east", "west"])

    cust = dict(age=age, bmi=bmi, children=children, exercise_freq=exercise,
                sex=sex, smoker=smoker, region=region)
    tier, premium = predict(cust)

    with right:
        st.subheader("Prediction (updates live)")
        m1, m2 = st.columns(2)
        m1.metric("Predicted risk tier", tier)
        m2.metric("Estimated annual premium", f"${premium:,.0f}")
        st.markdown(f"<div style='height:10px;border-radius:5px;background:{COLORS[tier]}'></div>",
                    unsafe_allow_html=True)
        proba = pd.Series(clf.predict_proba(pd.DataFrame([cust])[FEATURES])[0], index=clf.classes_).reindex(TIERS)
        st.write("**Tier confidence**")
        st.bar_chart(proba)

        # what-if: toggle smoker
        alt = dict(cust, smoker='no' if smoker == 'yes' else 'yes')
        t2, p2 = predict(alt)
        st.info(f"**What-if:** if smoker = **{alt['smoker']}** → tier **{t2}**, premium **${p2:,.0f}** "
                f"({p2 - premium:+,.0f})")

        # sensitivity of premium to each factor
        base = premium
        sens = {
            "Smoker flip": abs(p2 - base),
            "Age +10": abs(predict(dict(cust, age=min(age + 10, 64)))[1] - base),
            "BMI +5": abs(predict(dict(cust, bmi=bmi + 5))[1] - base),
            "Children +2": abs(predict(dict(cust, children=min(children + 2, 4)))[1] - base),
        }
        st.write("**Which change moves this customer's premium most?**")
        st.bar_chart(pd.Series(sens, name="|Δ premium| ($)"))

# ------------------------------------------------------------------ TAB 2
with tab2:
    st.subheader("Score many customers from a CSV")
    st.write("Required columns: `age, sex, bmi, children, smoker, region, exercise_freq` "
             "(missing bmi / exercise are filled with the training median).")
    up = st.file_uploader("Upload CSV", type="csv")
    if up:
        new = pd.read_csv(up)
        missing = [c for c in FEATURES if c not in new.columns and c not in NUM]
        if missing:
            st.error(f"Missing required columns: {missing}")
        else:
            out = [predict(dict(r)) for _, r in new.iterrows()]
            new["predicted_tier"] = [t for t, _ in out]
            new["predicted_premium"] = [round(p, 2) for _, p in out]
            st.dataframe(new)
            st.write(new["predicted_tier"].value_counts())
            st.download_button("⬇ Download predictions", new.to_csv(index=False), "predictions.csv")
    else:
        st.caption("Tip: `sample_customers.csv` is included in the project folder.")

# ------------------------------------------------------------------ TAB 3
with tab3:
    st.subheader("Board question 1 — does two-stage beat one global model?")
    e2e, glob = MET['end_to_end'], MET['global']
    a, b, c = st.columns(3)
    a.metric("Global model MAE", f"${e2e['global']['mae']:,.0f}")
    b.metric("Two-stage MAE", f"${e2e['two_stage']['mae']:,.0f}",
             f"-{(1 - e2e['two_stage']['mae'] / e2e['global']['mae']) * 100:.0f}% error", delta_color="inverse")
    c.metric("R²  global → two-stage", f"{e2e['global']['r2']:.2f} → {e2e['two_stage']['r2']:.2f}")
    st.caption("End-to-end on the same hold-out set: the classifier picks the tier, then that tier's regressor prices it.")

    st.markdown("---")
    l, r = st.columns(2)
    with l:
        st.subheader("Stage 1 — classifier")
        cl = MET['classifier']
        st.write(f"Chosen model: **{cl['chosen']}**")
        st.dataframe(pd.DataFrame(cl['candidates']).T.rename(columns={'train_acc': 'Train acc', 'test_acc': 'Test acc'}).round(3))
        cm = np.array(cl['confusion_matrix'])
        fig, ax = plt.subplots(figsize=(4, 3.2))
        ax.imshow(cm, cmap='Blues')
        ax.set_xticks(range(3)); ax.set_xticklabels(TIERS); ax.set_yticks(range(3)); ax.set_yticklabels(TIERS)
        ax.set_xlabel('Predicted'); ax.set_ylabel('Actual')
        for i in range(3):
            for j in range(3):
                ax.text(j, i, cm[i, j], ha='center', va='center',
                        color='white' if cm[i, j] > cm.max() / 2 else 'black')
        st.pyplot(fig)
    with r:
        st.subheader("Stage 2 — regression per tier")
        st.dataframe(pd.DataFrame({t: {'n': MET['tiers'][t]['n'], 'R²': round(MET['tiers'][t]['r2'], 3),
                                       'MAE ($)': round(MET['tiers'][t]['mae'])} for t in TIERS}).T)
        st.write("**Ridge / Lasso alpha sweep (test R²)**")
        tsel = st.selectbox("Tier", TIERS, index=2)
        sw = pd.DataFrame(MET['tiers'][tsel]['alpha_sweep']).T
        sw.index = sw.index.astype(float)
        st.line_chart(sw.rename(columns={'ridge': 'Ridge', 'lasso': 'Lasso'}))

# ------------------------------------------------------------------ TAB 4
with tab4:
    st.subheader("Which attributes drive cost?")
    tsel = st.radio("Tier", TIERS, horizontal=True, index=2, key='coef_tier')
    co = pd.Series(MET['coefficients'][tsel]).sort_values()
    fig, ax = plt.subplots(figsize=(6, 3.5))
    ax.barh(co.index, co.values, color=['#d64545' if v > 0 else '#2e9e5b' for v in co.values])
    ax.set_xlabel('Coefficient ($ per unit)'); ax.axvline(0, color='k', lw=.6)
    st.pyplot(fig)

    l, r = st.columns(2)
    with l:
        st.write("**Annual charge by tier**")
        fig, ax = plt.subplots(figsize=(5, 3.2))
        ax.boxplot([DATA[DATA.risk_tier == t].annual_charge for t in TIERS])
        ax.set_xticklabels(TIERS)
        ax.set_ylabel('Annual charge ($)')
        st.pyplot(fig)
    with r:
        st.write("**Columns dropped & why**")
        st.dataframe(pd.DataFrame(MET['dropped'], index=['Reason']).T)
    cl = MET['cleaning']
    st.caption(f"Cleaning: {cl['duplicates_removed']} duplicate rows removed; "
               f"{cl['missing_bmi']} missing BMI and {cl['missing_exercise']} missing exercise values filled with the median.")
